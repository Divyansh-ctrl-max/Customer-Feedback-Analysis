export interface SalesRecord {
  Order_ID: string;
  Order_Date: string;
  Region: string;
  State: string;
  City: string;
  Salesperson: string;
  Product: string;
  Category: string;
  Units_Sold: number;
  Unit_Price: number;
  Revenue: number;
  Cost: number;
  Profit: number;
  Customer_Type: string;
  Sales_Channel: string;
  Payment_Method: string;
  Order_Status: string;
}

export interface Filters {
  dateFrom: string;
  dateTo: string;
  region: string;
  state: string;
  category: string;
  product: string;
  salesperson: string;
  customerType: string;
  salesChannel: string;
  orderStatus: string;
}

export interface KPIData {
  totalRevenue: number;
  totalProfit: number;
  totalOrders: number;
  totalUnits: number;
  avgOrderValue: number;
  profitMargin: number;
}

export interface MonthlyData {
  month: string;
  monthKey: string;
  revenue: number;
  profit: number;
  orders: number;
  units: number;
}

export interface CategoryData {
  category: string;
  revenue: number;
  profit: number;
  units: number;
}

export interface RegionData {
  region: string;
  revenue: number;
  profit: number;
  units: number;
  orders: number;
}

export interface ProductData {
  product: string;
  revenue: number;
  profit: number;
  units: number;
}

export interface SalespersonData {
  salesperson: string;
  revenue: number;
  profit: number;
  orders: number;
}

export interface DistributionData {
  label: string;
  value: number;
}

export type ViewType = 'dashboard' | 'data' | 'insights';
