import type {
  SalesRecord, KPIData, MonthlyData, CategoryData,
  RegionData, ProductData, SalespersonData, DistributionData,
} from '@/types';

const MONTH_NAMES = [
  'Jan 2026', 'Feb 2026', 'Mar 2026', 'Apr 2026',
  'May 2026', 'Jun 2026', 'Jul 2026', 'Aug 2026',
];

export function computeKPIs(records: SalesRecord[]): KPIData {
  const totalRevenue = records.reduce((s, r) => s + r.Revenue, 0);
  const totalProfit = records.reduce((s, r) => s + r.Profit, 0);
  const totalOrders = records.length;
  const totalUnits = records.reduce((s, r) => s + r.Units_Sold, 0);
  const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
  const profitMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;
  return { totalRevenue, totalProfit, totalOrders, totalUnits, avgOrderValue, profitMargin };
}

export function computeMonthlyData(records: SalesRecord[]): MonthlyData[] {
  const map = new Map<number, MonthlyData>();
  for (let m = 0; m < 8; m++) {
    map.set(m, { month: MONTH_NAMES[m], monthKey: `2026-${String(m + 1).padStart(2, '0')}`, revenue: 0, profit: 0, orders: 0, units: 0 });
  }
  for (const r of records) {
    const monthIdx = parseInt(r.Order_Date.substring(5, 7), 10) - 1;
    if (monthIdx < 0 || monthIdx > 7) continue;
    const entry = map.get(monthIdx)!;
    entry.revenue += r.Revenue;
    entry.profit += r.Profit;
    entry.orders += 1;
    entry.units += r.Units_Sold;
  }
  return Array.from(map.values()).map((d) => ({
    ...d,
    revenue: Math.round(d.revenue * 100) / 100,
    profit: Math.round(d.profit * 100) / 100,
  }));
}

export function computeRegionData(records: SalesRecord[]): RegionData[] {
  const map = new Map<string, RegionData>();
  for (const r of records) {
    if (!map.has(r.Region)) {
      map.set(r.Region, { region: r.Region, revenue: 0, profit: 0, units: 0, orders: 0 });
    }
    const entry = map.get(r.Region)!;
    entry.revenue += r.Revenue;
    entry.profit += r.Profit;
    entry.units += r.Units_Sold;
    entry.orders += 1;
  }
  return Array.from(map.values()).map((d) => ({
    ...d,
    revenue: Math.round(d.revenue * 100) / 100,
    profit: Math.round(d.profit * 100) / 100,
  })).sort((a, b) => b.revenue - a.revenue);
}

export function computeCategoryData(records: SalesRecord[]): CategoryData[] {
  const map = new Map<string, CategoryData>();
  for (const r of records) {
    if (!map.has(r.Category)) {
      map.set(r.Category, { category: r.Category, revenue: 0, profit: 0, units: 0 });
    }
    const entry = map.get(r.Category)!;
    entry.revenue += r.Revenue;
    entry.profit += r.Profit;
    entry.units += r.Units_Sold;
  }
  return Array.from(map.values()).map((d) => ({
    ...d,
    revenue: Math.round(d.revenue * 100) / 100,
    profit: Math.round(d.profit * 100) / 100,
  })).sort((a, b) => b.revenue - a.revenue);
}

export function computeTopProducts(records: SalesRecord[], topN = 10): ProductData[] {
  const map = new Map<string, ProductData>();
  for (const r of records) {
    if (!map.has(r.Product)) {
      map.set(r.Product, { product: r.Product, revenue: 0, profit: 0, units: 0 });
    }
    const entry = map.get(r.Product)!;
    entry.revenue += r.Revenue;
    entry.profit += r.Profit;
    entry.units += r.Units_Sold;
  }
  return Array.from(map.values()).map((d) => ({
    ...d,
    revenue: Math.round(d.revenue * 100) / 100,
    profit: Math.round(d.profit * 100) / 100,
  })).sort((a, b) => b.revenue - a.revenue).slice(0, topN);
}

export function computeSalespersonData(records: SalesRecord[]): SalespersonData[] {
  const map = new Map<string, SalespersonData>();
  for (const r of records) {
    if (!map.has(r.Salesperson)) {
      map.set(r.Salesperson, { salesperson: r.Salesperson, revenue: 0, profit: 0, orders: 0 });
    }
    const entry = map.get(r.Salesperson)!;
    entry.revenue += r.Revenue;
    entry.profit += r.Profit;
    entry.orders += 1;
  }
  return Array.from(map.values()).map((d) => ({
    ...d,
    revenue: Math.round(d.revenue * 100) / 100,
    profit: Math.round(d.profit * 100) / 100,
  })).sort((a, b) => b.revenue - a.revenue);
}

export function computeDistribution(records: SalesRecord[], field: keyof SalesRecord): DistributionData[] {
  const map = new Map<string, number>();
  for (const r of records) {
    const key = r[field] as string;
    map.set(key, (map.get(key) ?? 0) + 1);
  }
  return Array.from(map.entries()).map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);
}

export function computeRevenueDistribution(records: SalesRecord[], field: keyof SalesRecord): DistributionData[] {
  const map = new Map<string, number>();
  for (const r of records) {
    const key = r[field] as string;
    map.set(key, (map.get(key) ?? 0) + r.Revenue);
  }
  return Array.from(map.entries()).map(([label, value]) => ({ label, value: Math.round(value * 100) / 100 })).sort((a, b) => b.value - a.value);
}

export function formatCurrency(value: number): string {
  if (Math.abs(value) >= 10000000) return `₹${(value / 10000000).toFixed(2)} Cr`;
  if (Math.abs(value) >= 100000) return `₹${(value / 100000).toFixed(2)} L`;
  if (Math.abs(value) >= 1000) return `₹${(value.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
  return `₹${value.toFixed(0)}`;
}

export function formatNumber(value: number): string {
  return value.toLocaleString('en-IN', { maximumFractionDigits: 0 });
}

export function formatPercent(value: number): string {
  return `${value.toFixed(1)}%`;
}
