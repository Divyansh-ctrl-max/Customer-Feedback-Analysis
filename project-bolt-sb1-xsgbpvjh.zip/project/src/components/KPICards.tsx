import { TrendingUp, DollarSign, ShoppingCart, Package, BarChart3, Percent } from 'lucide-react';
import type { KPIData } from '@/types';
import { formatCurrency, formatNumber, formatPercent } from '@/utils/analytics';

interface KPICardsProps {
  kpis: KPIData;
}

const cardConfig = [
  { key: 'totalRevenue', label: 'Total Revenue', icon: DollarSign, color: 'teal', format: (v: number) => formatCurrency(v) },
  { key: 'totalProfit', label: 'Total Profit', icon: TrendingUp, color: 'emerald', format: (v: number) => formatCurrency(v) },
  { key: 'totalOrders', label: 'Total Orders', icon: ShoppingCart, color: 'blue', format: (v: number) => formatNumber(v) },
  { key: 'totalUnits', label: 'Units Sold', icon: Package, color: 'amber', format: (v: number) => formatNumber(v) },
  { key: 'avgOrderValue', label: 'Avg Order Value', icon: BarChart3, color: 'indigo', format: (v: number) => formatCurrency(v) },
  { key: 'profitMargin', label: 'Profit Margin', icon: Percent, color: 'rose', format: (v: number) => formatPercent(v) },
];

const colorMap: Record<string, { bg: string; text: string; border: string; iconBg: string }> = {
  teal: { bg: 'bg-teal-50', text: 'text-teal-700', border: 'border-teal-200', iconBg: 'bg-teal-500' },
  emerald: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200', iconBg: 'bg-emerald-500' },
  blue: { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200', iconBg: 'bg-blue-500' },
  amber: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', iconBg: 'bg-amber-500' },
  indigo: { bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-200', iconBg: 'bg-indigo-500' },
  rose: { bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-200', iconBg: 'bg-rose-500' },
};

export default function KPICards({ kpis }: KPICardsProps) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
      {cardConfig.map((card) => {
        const c = colorMap[card.color];
        const Icon = card.icon;
        const value = kpis[card.key as keyof KPIData];
        return (
          <div
            key={card.key}
            className={`rounded-xl border ${c.border} ${c.bg} p-4 shadow-sm transition hover:shadow-md`}
          >
            <div className="mb-2 flex items-center justify-between">
              <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${c.iconBg} shadow-sm`}>
                <Icon className="h-5 w-5 text-white" />
              </div>
            </div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{card.label}</p>
            <p className={`mt-1 text-xl font-bold ${c.text} sm:text-2xl`}>{card.format(value)}</p>
          </div>
        );
      })}
    </div>
  );
}
