import {
  ResponsiveContainer, AreaChart, Area, LineChart, Line,
  BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from 'recharts';
import type {
  MonthlyData, RegionData, CategoryData, ProductData,
  SalespersonData, DistributionData,
} from '@/types';
import { formatCurrency } from '@/utils/analytics';

const CHART_COLORS = [
  '#0d9488', '#6366f1', '#f59e0b', '#ec4899',
  '#3b82f6', '#10b981', '#8b5cf6', '#ef4444',
  '#14b8a6', '#f97316',
];

const tooltipStyle = {
  backgroundColor: '#fff',
  border: '1px solid #e2e8f0',
  borderRadius: '8px',
  fontSize: '12px',
  boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)',
};

const axisStyle = { fontSize: 11, fill: '#64748b' };

function ChartCard({ title, children, className }: { title: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-xl border border-slate-200 bg-white p-4 shadow-sm ${className ?? ''}`}>
      <h3 className="mb-3 text-sm font-bold text-slate-700">{title}</h3>
      {children}
    </div>
  );
}

export function MonthlyRevenueChart({ data }: { data: MonthlyData[] }) {
  return (
    <ChartCard title="Monthly Revenue Trend">
      <ResponsiveContainer width="100%" height={260}>
        <AreaChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#0d9488" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#0d9488" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis dataKey="month" tick={axisStyle} tickLine={false} axisLine={false} />
          <YAxis tick={axisStyle} tickLine={false} axisLine={false} tickFormatter={(v) => formatCurrency(v)} width={70} />
          <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatCurrency(v)} />
          <Area type="monotone" dataKey="revenue" stroke="#0d9488" strokeWidth={2} fill="url(#revGrad)" name="Revenue" />
        </AreaChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

export function MonthlyProfitChart({ data }: { data: MonthlyData[] }) {
  return (
    <ChartCard title="Monthly Profit Trend">
      <ResponsiveContainer width="100%" height={260}>
        <LineChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis dataKey="month" tick={axisStyle} tickLine={false} axisLine={false} />
          <YAxis tick={axisStyle} tickLine={false} axisLine={false} tickFormatter={(v) => formatCurrency(v)} width={70} />
          <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatCurrency(v)} />
          <Line type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={2.5} dot={{ r: 4, fill: '#10b981' }} name="Profit" />
        </LineChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

export function RegionRevenueChart({ data }: { data: RegionData[] }) {
  return (
    <ChartCard title="Revenue by Region">
      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis dataKey="region" tick={axisStyle} tickLine={false} axisLine={false} />
          <YAxis tick={axisStyle} tickLine={false} axisLine={false} tickFormatter={(v) => formatCurrency(v)} width={70} />
          <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatCurrency(v)} cursor={{ fill: '#f8fafc' }} />
          <Bar dataKey="revenue" name="Revenue" radius={[6, 6, 0, 0]}>
            {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

export function RegionProfitChart({ data }: { data: RegionData[] }) {
  return (
    <ChartCard title="Profit by Region">
      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis dataKey="region" tick={axisStyle} tickLine={false} axisLine={false} />
          <YAxis tick={axisStyle} tickLine={false} axisLine={false} tickFormatter={(v) => formatCurrency(v)} width={70} />
          <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatCurrency(v)} cursor={{ fill: '#f8fafc' }} />
          <Bar dataKey="profit" name="Profit" radius={[6, 6, 0, 0]} fill="#10b981" />
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

export function CategoryRevenueChart({ data }: { data: CategoryData[] }) {
  return (
    <ChartCard title="Revenue by Product Category">
      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={data} layout="vertical" margin={{ top: 5, right: 10, left: 80, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis type="number" tick={axisStyle} tickLine={false} axisLine={false} tickFormatter={(v) => formatCurrency(v)} />
          <YAxis type="category" dataKey="category" tick={axisStyle} tickLine={false} axisLine={false} width={80} />
          <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatCurrency(v)} cursor={{ fill: '#f8fafc' }} />
          <Bar dataKey="revenue" name="Revenue" radius={[0, 6, 6, 0]}>
            {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

export function TopProductsChart({ data }: { data: ProductData[] }) {
  return (
    <ChartCard title="Top 10 Products by Revenue">
      <ResponsiveContainer width="100%" height={320}>
        <BarChart data={data} layout="vertical" margin={{ top: 5, right: 10, left: 120, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis type="number" tick={axisStyle} tickLine={false} axisLine={false} tickFormatter={(v) => formatCurrency(v)} />
          <YAxis type="category" dataKey="product" tick={axisStyle} tickLine={false} axisLine={false} width={120} />
          <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatCurrency(v)} cursor={{ fill: '#f8fafc' }} />
          <Bar dataKey="revenue" name="Revenue" radius={[0, 4, 4, 0]}>
            {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

export function SalespersonChart({ data }: { data: SalespersonData[] }) {
  return (
    <ChartCard title="Salesperson Performance (Revenue & Profit)">
      <ResponsiveContainer width="100%" height={340}>
        <BarChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis dataKey="salesperson" tick={axisStyle} tickLine={false} axisLine={false} angle={-45} textAnchor="end" height={60} interval={0} />
          <YAxis tick={axisStyle} tickLine={false} axisLine={false} tickFormatter={(v) => formatCurrency(v)} width={70} />
          <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatCurrency(v)} cursor={{ fill: '#f8fafc' }} />
          <Legend wrapperStyle={{ fontSize: 11 }} />
          <Bar dataKey="revenue" name="Revenue" fill="#0d9488" radius={[4, 4, 0, 0]} />
          <Bar dataKey="profit" name="Profit" fill="#10b981" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

export function CustomerTypeChart({ data }: { data: DistributionData[] }) {
  return (
    <ChartCard title="New vs Returning Customers">
      <ResponsiveContainer width="100%" height={260}>
        <PieChart>
          <Pie data={data} dataKey="value" nameKey="label" cx="50%" cy="50%" outerRadius={80} innerRadius={45} paddingAngle={3}>
            {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
          </Pie>
          <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => `${v} orders`} />
          <Legend wrapperStyle={{ fontSize: 11 }} />
        </PieChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

export function ChannelChart({ data }: { data: DistributionData[] }) {
  return (
    <ChartCard title="Online vs Offline Sales">
      <ResponsiveContainer width="100%" height={260}>
        <PieChart>
          <Pie data={data} dataKey="value" nameKey="label" cx="50%" cy="50%" outerRadius={80} innerRadius={45} paddingAngle={3}>
            {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[(i + 2) % CHART_COLORS.length]} />)}
          </Pie>
          <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => `${v} orders`} />
          <Legend wrapperStyle={{ fontSize: 11 }} />
        </PieChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

export function OrderStatusChart({ data }: { data: DistributionData[] }) {
  return (
    <ChartCard title="Order Status Distribution">
      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis dataKey="label" tick={axisStyle} tickLine={false} axisLine={false} />
          <YAxis tick={axisStyle} tickLine={false} axisLine={false} width={50} />
          <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => `${v} orders`} cursor={{ fill: '#f8fafc' }} />
          <Bar dataKey="value" name="Orders" radius={[6, 6, 0, 0]}>
            {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[(i + 4) % CHART_COLORS.length]} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}
