import { Filter, X, RotateCcw } from 'lucide-react';
import type { Filters, SalesRecord } from '@/types';
import { getUniqueValues, getDateRange } from '@/data/parseData';

interface FilterBarProps {
  filters: Filters;
  setFilters: (f: Filters) => void;
  allRecords: SalesRecord[];
  filteredCount: number;
}

const selectClass =
  'w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 shadow-sm transition focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500 hover:border-slate-300 appearance-none cursor-pointer';

const labelClass = 'block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wide';

export default function FilterBar({ filters, setFilters, allRecords, filteredCount }: FilterBarProps) {
  const { min, max } = getDateRange(allRecords);

  const regions = getUniqueValues(allRecords, 'Region');
  const states = getUniqueValues(
    filters.region ? allRecords.filter((r) => r.Region === filters.region) : allRecords,
    'State'
  );
  const categories = getUniqueValues(allRecords, 'Category');
  const products = getUniqueValues(
    filters.category ? allRecords.filter((r) => r.Category === filters.category) : allRecords,
    'Product'
  );
  const salespeople = getUniqueValues(allRecords, 'Salesperson');
  const customerTypes = getUniqueValues(allRecords, 'Customer_Type');
  const channels = getUniqueValues(allRecords, 'Sales_Channel');
  const orderStatuses = getUniqueValues(allRecords, 'Order_Status');

  const update = (key: keyof Filters, value: string) => {
    const next = { ...filters, [key]: value };
    if (key === 'region') next.state = '';
    if (key === 'category') next.product = '';
    setFilters(next);
  };

  const reset = () => {
    setFilters({
      dateFrom: '', dateTo: '', region: '', state: '', category: '',
      product: '', salesperson: '', customerType: '', salesChannel: '', orderStatus: '',
    });
  };

  const activeCount = Object.values(filters).filter((v) => v !== '').length;

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-teal-600" />
          <span className="text-sm font-bold text-slate-700">Filters</span>
          {activeCount > 0 && (
            <span className="rounded-full bg-teal-100 px-2 py-0.5 text-xs font-semibold text-teal-700">
              {activeCount} active
            </span>
          )}
          <span className="ml-2 text-xs text-slate-400">
            {filteredCount} of {allRecords.length} records
          </span>
        </div>
        {activeCount > 0 && (
          <button
            onClick={reset}
            className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-slate-500 transition hover:bg-slate-100 hover:text-slate-700"
          >
            <RotateCcw className="h-3 w-3" /> Reset
          </button>
        )}
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <div>
          <label className={labelClass}>From Date</label>
          <input
            type="date" min={min} max={max}
            value={filters.dateFrom}
            onChange={(e) => update('dateFrom', e.target.value)}
            className={selectClass}
          />
        </div>
        <div>
          <label className={labelClass}>To Date</label>
          <input
            type="date" min={min} max={max}
            value={filters.dateTo}
            onChange={(e) => update('dateTo', e.target.value)}
            className={selectClass}
          />
        </div>
        <div>
          <label className={labelClass}>Region</label>
          <select value={filters.region} onChange={(e) => update('region', e.target.value)} className={selectClass}>
            <option value="">All Regions</option>
            {regions.map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
        </div>
        <div>
          <label className={labelClass}>State</label>
          <select value={filters.state} onChange={(e) => update('state', e.target.value)} className={selectClass}>
            <option value="">All States</option>
            {states.map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
        </div>
        <div>
          <label className={labelClass}>Category</label>
          <select value={filters.category} onChange={(e) => update('category', e.target.value)} className={selectClass}>
            <option value="">All Categories</option>
            {categories.map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
        </div>
        <div>
          <label className={labelClass}>Product</label>
          <select value={filters.product} onChange={(e) => update('product', e.target.value)} className={selectClass}>
            <option value="">All Products</option>
            {products.map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
        </div>
        <div>
          <label className={labelClass}>Salesperson</label>
          <select value={filters.salesperson} onChange={(e) => update('salesperson', e.target.value)} className={selectClass}>
            <option value="">All Salespeople</option>
            {salespeople.map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
        </div>
        <div>
          <label className={labelClass}>Customer Type</label>
          <select value={filters.customerType} onChange={(e) => update('customerType', e.target.value)} className={selectClass}>
            <option value="">All Types</option>
            {customerTypes.map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
        </div>
        <div>
          <label className={labelClass}>Sales Channel</label>
          <select value={filters.salesChannel} onChange={(e) => update('salesChannel', e.target.value)} className={selectClass}>
            <option value="">All Channels</option>
            {channels.map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
        </div>
        <div>
          <label className={labelClass}>Order Status</label>
          <select value={filters.orderStatus} onChange={(e) => update('orderStatus', e.target.value)} className={selectClass}>
            <option value="">All Statuses</option>
            {orderStatuses.map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
        </div>
      </div>
    </div>
  );
}
