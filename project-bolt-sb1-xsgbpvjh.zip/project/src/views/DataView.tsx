import { useMemo, useState } from 'react';
import { Search, ChevronLeft, ChevronRight, ArrowUpDown } from 'lucide-react';
import type { SalesRecord, Filters } from '@/types';
import { applyFilters } from '@/data/parseData';
import { formatCurrency } from '@/utils/analytics';
import FilterBar from '@/components/FilterBar';

interface DataViewProps {
  allRecords: SalesRecord[];
  filters: Filters;
  setFilters: (f: Filters) => void;
}

const COLUMNS: { key: keyof SalesRecord; label: string; align?: string }[] = [
  { key: 'Order_ID', label: 'Order ID' },
  { key: 'Order_Date', label: 'Date' },
  { key: 'Region', label: 'Region' },
  { key: 'State', label: 'State' },
  { key: 'City', label: 'City' },
  { key: 'Salesperson', label: 'Salesperson' },
  { key: 'Product', label: 'Product' },
  { key: 'Category', label: 'Category' },
  { key: 'Units_Sold', label: 'Units', align: 'right' },
  { key: 'Unit_Price', label: 'Unit Price', align: 'right' },
  { key: 'Revenue', label: 'Revenue', align: 'right' },
  { key: 'Cost', label: 'Cost', align: 'right' },
  { key: 'Profit', label: 'Profit', align: 'right' },
  { key: 'Customer_Type', label: 'Cust. Type' },
  { key: 'Sales_Channel', label: 'Channel' },
  { key: 'Payment_Method', label: 'Payment' },
  { key: 'Order_Status', label: 'Status' },
];

const statusColors: Record<string, string> = {
  Completed: 'bg-emerald-100 text-emerald-700',
  Cancelled: 'bg-rose-100 text-rose-700',
  Returned: 'bg-amber-100 text-amber-700',
};

export default function DataView({ allRecords, filters, setFilters }: DataViewProps) {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(0);
  const [sortKey, setSortKey] = useState<keyof SalesRecord>('Order_Date');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const pageSize = 25;

  const filtered = useMemo(() => {
    let data = applyFilters(allRecords, filters);
    if (search) {
      const q = search.toLowerCase();
      data = data.filter((r) =>
        r.Order_ID.toLowerCase().includes(q) ||
        r.Salesperson.toLowerCase().includes(q) ||
        r.Product.toLowerCase().includes(q) ||
        r.City.toLowerCase().includes(q) ||
        r.State.toLowerCase().includes(q)
      );
    }
    data = [...data].sort((a, b) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      let cmp = 0;
      if (typeof av === 'number' && typeof bv === 'number') cmp = av - bv;
      else cmp = String(av).localeCompare(String(bv));
      return sortDir === 'asc' ? cmp : -cmp;
    });
    return data;
  }, [allRecords, filters, search, sortKey, sortDir]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const pageData = filtered.slice(page * pageSize, (page + 1) * pageSize);

  const handleSort = (key: keyof SalesRecord) => {
    if (sortKey === key) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDir('desc');
    }
  };

  return (
    <div className="space-y-5">
      <FilterBar filters={filters} setFilters={setFilters} allRecords={allRecords} filteredCount={filtered.length} />

      <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="flex flex-col gap-3 border-b border-slate-100 p-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search orders, products, people..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(0); }}
              className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-3 text-sm text-slate-700 transition focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>
          <p className="text-sm text-slate-500">
            Showing <span className="font-semibold text-slate-700">{pageData.length}</span> of{' '}
            <span className="font-semibold text-slate-700">{filtered.length}</span> records
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50">
                {COLUMNS.map((col) => (
                  <th
                    key={col.key}
                    onClick={() => handleSort(col.key)}
                    className={`cursor-pointer px-3 py-2.5 text-xs font-semibold uppercase tracking-wide text-slate-500 transition hover:text-slate-700 ${col.align === 'right' ? 'text-right' : 'text-left'}`}
                  >
                    <span className="inline-flex items-center gap-1">
                      {col.label}
                      <ArrowUpDown className="h-3 w-3 opacity-40" />
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageData.map((r) => (
                <tr key={r.Order_ID} className="border-b border-slate-50 transition hover:bg-slate-50">
                  <td className="whitespace-nowrap px-3 py-2 font-medium text-slate-700">{r.Order_ID}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-slate-600">{r.Order_Date}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-slate-600">{r.Region}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-slate-600">{r.State}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-slate-600">{r.City}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-slate-600">{r.Salesperson}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-slate-600">{r.Product}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-slate-600">{r.Category}</td>
                  <td className="px-3 py-2 text-right text-slate-600">{r.Units_Sold}</td>
                  <td className="px-3 py-2 text-right text-slate-600">{formatCurrency(r.Unit_Price)}</td>
                  <td className="px-3 py-2 text-right font-medium text-teal-700">{formatCurrency(r.Revenue)}</td>
                  <td className="px-3 py-2 text-right text-slate-500">{formatCurrency(r.Cost)}</td>
                  <td className="px-3 py-2 text-right font-medium text-emerald-700">{formatCurrency(r.Profit)}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-slate-600">{r.Customer_Type}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-slate-600">{r.Sales_Channel}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-slate-600">{r.Payment_Method}</td>
                  <td className="whitespace-nowrap px-3 py-2">
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${statusColors[r.Order_Status] ?? 'bg-slate-100 text-slate-600'}`}>
                      {r.Order_Status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between border-t border-slate-100 p-4">
          <p className="text-xs text-slate-400">
            Page {page + 1} of {totalPages || 1}
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => setPage(Math.max(0, page - 1))}
              disabled={page === 0}
              className="flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-1.5 text-sm text-slate-600 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <ChevronLeft className="h-4 w-4" /> Prev
            </button>
            <button
              onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
              disabled={page >= totalPages - 1}
              className="flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-1.5 text-sm text-slate-600 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Next <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
