import { useMemo } from 'react';
import type { SalesRecord, Filters } from '@/types';
import { applyFilters } from '@/data/parseData';
import {
  computeKPIs, computeMonthlyData, computeRegionData, computeCategoryData,
  computeTopProducts, computeSalespersonData, computeDistribution,
} from '@/utils/analytics';
import KPICards from '@/components/KPICards';
import FilterBar from '@/components/FilterBar';
import {
  MonthlyRevenueChart, MonthlyProfitChart, RegionRevenueChart,
  RegionProfitChart, CategoryRevenueChart, TopProductsChart,
  SalespersonChart, CustomerTypeChart, ChannelChart, OrderStatusChart,
} from '@/components/Charts';

interface DashboardViewProps {
  allRecords: SalesRecord[];
  filters: Filters;
  setFilters: (f: Filters) => void;
}

export default function DashboardView({ allRecords, filters, setFilters }: DashboardViewProps) {
  const filtered = useMemo(() => applyFilters(allRecords, filters), [allRecords, filters]);

  const kpis = useMemo(() => computeKPIs(filtered), [filtered]);
  const monthly = useMemo(() => computeMonthlyData(filtered), [filtered]);
  const regions = useMemo(() => computeRegionData(filtered), [filtered]);
  const categories = useMemo(() => computeCategoryData(filtered), [filtered]);
  const topProducts = useMemo(() => computeTopProducts(filtered, 10), [filtered]);
  const salespeople = useMemo(() => computeSalespersonData(filtered), [filtered]);
  const customerDist = useMemo(() => computeDistribution(filtered, 'Customer_Type'), [filtered]);
  const channelDist = useMemo(() => computeDistribution(filtered, 'Sales_Channel'), [filtered]);
  const statusDist = useMemo(() => computeDistribution(filtered, 'Order_Status'), [filtered]);

  return (
    <div className="space-y-5">
      <FilterBar filters={filters} setFilters={setFilters} allRecords={allRecords} filteredCount={filtered.length} />

      <KPICards kpis={kpis} />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <MonthlyRevenueChart data={monthly} />
        <MonthlyProfitChart data={monthly} />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <RegionRevenueChart data={regions} />
        <RegionProfitChart data={regions} />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <CategoryRevenueChart data={categories} />
        <TopProductsChart data={topProducts} />
      </div>

      <SalespersonChart data={salespeople} />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <CustomerTypeChart data={customerDist} />
        <ChannelChart data={channelDist} />
        <OrderStatusChart data={statusDist} />
      </div>
    </div>
  );
}
