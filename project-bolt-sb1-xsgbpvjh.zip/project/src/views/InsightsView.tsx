import { useMemo } from 'react';
import {
  Lightbulb, TrendingUp, AlertTriangle, Target,
  Award, Calendar, MapPin, Package, BarChart3, BookOpen,
} from 'lucide-react';
import type { SalesRecord, Filters } from '@/types';
import { applyFilters } from '@/data/parseData';
import {
  computeKPIs, computeMonthlyData, computeRegionData, computeCategoryData,
  computeTopProducts, computeSalespersonData, computeDistribution,
  formatCurrency, formatPercent,
} from '@/utils/analytics';
import FilterBar from '@/components/FilterBar';

interface InsightsViewProps {
  allRecords: SalesRecord[];
  filters: Filters;
  setFilters: (f: Filters) => void;
}

function InsightCard({
  icon: Icon, title, children, accent,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  children: React.ReactNode;
  accent: string;
}) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="mb-3 flex items-center gap-2">
        <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${accent}`}>
          <Icon className="h-5 w-5 text-white" />
        </div>
        <h3 className="text-sm font-bold text-slate-700">{title}</h3>
      </div>
      <div className="text-sm leading-relaxed text-slate-600">{children}</div>
    </div>
  );
}

export default function InsightsView({ allRecords, filters, setFilters }: InsightsViewProps) {
  const filtered = useMemo(() => applyFilters(allRecords, filters), [allRecords, filters]);

  const kpis = useMemo(() => computeKPIs(filtered), [filtered]);
  const monthly = useMemo(() => computeMonthlyData(filtered), [filtered]);
  const regions = useMemo(() => computeRegionData(filtered), [filtered]);
  const categories = useMemo(() => computeCategoryData(filtered), [filtered]);
  const topProducts = useMemo(() => computeTopProducts(filtered, 5), [filtered]);
  const salespeople = useMemo(() => computeSalespersonData(filtered), [filtered]);
  const statusDist = useMemo(() => computeDistribution(filtered, 'Order_Status'), [filtered]);
  const channelDist = useMemo(() => computeDistribution(filtered, 'Sales_Channel'), [filtered]);
  const customerDist = useMemo(() => computeDistribution(filtered, 'Customer_Type'), [filtered]);

  // Derived insights
  const bestRegion = regions[0];
  const bestCategory = categories[0];
  const bestProduct = topProducts[0];
  const bestMonth = useMemo(
    () => [...monthly].sort((a, b) => b.revenue - a.revenue)[0],
    [monthly]
  );
  const worstMonth = useMemo(
    () => [...monthly].sort((a, b) => a.revenue - b.revenue)[0],
    [monthly]
  );
  const topSalesperson = salespeople[0];
  const bottomSalesperson = salespeople[salespeople.length - 1];

  const completedCount = statusDist.find((s) => s.label === 'Completed')?.value ?? 0;
  const cancelledCount = statusDist.find((s) => s.label === 'Cancelled')?.value ?? 0;
  const returnedCount = statusDist.find((s) => s.label === 'Returned')?.value ?? 0;
  const completionRate = filtered.length > 0 ? (completedCount / filtered.length) * 100 : 0;
  const cancellationRate = filtered.length > 0 ? (cancelledCount / filtered.length) * 100 : 0;
  const returnRate = filtered.length > 0 ? (returnedCount / filtered.length) * 100 : 0;

  const onlineCount = channelDist.find((c) => c.label === 'Online')?.value ?? 0;
  const offlineCount = channelDist.find((c) => c.label === 'Offline')?.value ?? 0;
  const onlinePct = filtered.length > 0 ? (onlineCount / filtered.length) * 100 : 0;

  const returningCount = customerDist.find((c) => c.label === 'Returning')?.value ?? 0;
  const newCount = customerDist.find((c) => c.label === 'New')?.value ?? 0;
  const returningPct = filtered.length > 0 ? (returningCount / filtered.length) * 100 : 0;

  const totalRevenue = kpis.totalRevenue;
  const totalProfit = kpis.totalProfit;
  const profitMargin = kpis.profitMargin;

  return (
    <div className="space-y-5">
      <FilterBar filters={filters} setFilters={setFilters} allRecords={allRecords} filteredCount={filtered.length} />

      {/* Executive Summary */}
      <div className="rounded-xl border border-slate-200 bg-gradient-to-br from-slate-50 to-white p-6 shadow-sm">
        <div className="mb-4 flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-teal-600" />
          <h2 className="text-lg font-bold text-slate-800">Executive Summary</h2>
        </div>
        <p className="mb-4 text-sm leading-relaxed text-slate-600">
          This analysis covers <strong>{filtered.length} orders</strong> generating{' '}
          <strong>{formatCurrency(totalRevenue)}</strong> in revenue and{' '}
          <strong>{formatCurrency(totalProfit)}</strong> in profit, with an overall profit margin of{' '}
          <strong>{formatPercent(profitMargin)}</strong>. The dataset spans January through August 2026 across
          four Indian regional markets, five product categories, and twelve distinct products.
        </p>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="flex items-center gap-3 rounded-lg border border-teal-100 bg-teal-50 p-3">
            <MapPin className="h-5 w-5 text-teal-600" />
            <div>
              <p className="text-xs font-semibold uppercase text-teal-600">Best Region</p>
              <p className="text-sm font-bold text-slate-700">{bestRegion?.region ?? '—'}</p>
              <p className="text-xs text-slate-500">{formatCurrency(bestRegion?.revenue ?? 0)} revenue</p>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-lg border border-indigo-100 bg-indigo-50 p-3">
            <Award className="h-5 w-5 text-indigo-600" />
            <div>
              <p className="text-xs font-semibold uppercase text-indigo-600">Best Category</p>
              <p className="text-sm font-bold text-slate-700">{bestCategory?.category ?? '—'}</p>
              <p className="text-xs text-slate-500">{formatCurrency(bestCategory?.revenue ?? 0)} revenue</p>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-lg border border-amber-100 bg-amber-50 p-3">
            <Package className="h-5 w-5 text-amber-600" />
            <div>
              <p className="text-xs font-semibold uppercase text-amber-600">Best Product</p>
              <p className="text-sm font-bold text-slate-700">{bestProduct?.product ?? '—'}</p>
              <p className="text-xs text-slate-500">{formatCurrency(bestProduct?.revenue ?? 0)} revenue</p>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-lg border border-emerald-100 bg-emerald-50 p-3">
            <Calendar className="h-5 w-5 text-emerald-600" />
            <div>
              <p className="text-xs font-semibold uppercase text-emerald-600">Top Month</p>
              <p className="text-sm font-bold text-slate-700">{bestMonth?.month ?? '—'}</p>
              <p className="text-xs text-slate-500">{formatCurrency(bestMonth?.revenue ?? 0)} revenue</p>
            </div>
          </div>
        </div>
      </div>

      {/* Key Findings */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <InsightCard icon={TrendingUp} title="Key Business Findings" accent="bg-teal-500">
          <ul className="space-y-2">
            <li>
              <strong>{bestRegion?.region}</strong> leads regional performance with{' '}
              {formatCurrency(bestRegion?.revenue ?? 0)} in revenue ({formatPercent((bestRegion?.revenue ?? 0) / totalRevenue * 100)} of total),
              followed by {regions[1]?.region} ({formatCurrency(regions[1]?.revenue ?? 0)}).
            </li>
            <li>
              <strong>{bestCategory?.category}</strong> is the highest-grossing category at{' '}
              {formatCurrency(bestCategory?.revenue ?? 0)}, while{' '}
              {categories[categories.length - 1]?.category} trails at{' '}
              {formatCurrency(categories[categories.length - 1]?.revenue ?? 0)}.
            </li>
            <li>
              The top-selling product is <strong>{bestProduct?.product}</strong> with{' '}
              {formatCurrency(bestProduct?.revenue ?? 0)} in revenue across {bestProduct?.units ?? 0} units sold.
            </li>
            <li>
              <strong>{bestMonth?.month}</strong> was the strongest month ({formatCurrency(bestMonth?.revenue ?? 0)}),
              while {worstMonth?.month} was the weakest ({formatCurrency(worstMonth?.revenue ?? 0)}).
            </li>
            <li>
              {topSalesperson?.salesperson} is the top performer ({formatCurrency(topSalesperson?.revenue ?? 0)} revenue,
              {' '}{topSalesperson?.orders ?? 0} orders), while {bottomSalesperson?.salesperson} generated the least
              ({formatCurrency(bottomSalesperson?.revenue ?? 0)}).
            </li>
            <li>
              Online channels account for {formatPercent(onlinePct)} of orders ({onlineCount} of {filtered.length}),
              with {formatPercent(100 - onlinePct)} from offline retail.
            </li>
            <li>
              Returning customers represent {formatPercent(returningPct)} of orders ({returningCount}),
              vs {formatPercent(100 - returningPct)} new customers ({newCount}).
            </li>
          </ul>
        </InsightCard>

        <InsightCard icon={AlertTriangle} title="Areas of Concern" accent="bg-rose-500">
          <ul className="space-y-2">
            <li>
              <strong>Order fulfilment issues:</strong> {formatPercent(cancellationRate + returnRate)} of orders
              ({cancelledCount + returnedCount} of {filtered.length}) were cancelled or returned —
              {' '}{cancelledCount} cancelled ({formatPercent(cancellationRate)}) and {returnedCount} returned ({formatPercent(returnRate)}).
              This represents lost revenue and potential customer dissatisfaction.
            </li>
            <li>
              <strong>Regional imbalance:</strong> {regions[regions.length - 1]?.region} generates only{' '}
              {formatCurrency(regions[regions.length - 1]?.revenue ?? 0)} — roughly{' '}
              {formatPercent((regions[regions.length - 1]?.revenue ?? 0) / totalRevenue * 100)} of total revenue,
              indicating underpenetration in that market.
            </li>
            <li>
              <strong>Category concentration risk:</strong> {bestCategory?.category} alone contributes{' '}
              {formatPercent((bestCategory?.revenue ?? 0) / totalRevenue * 100)} of revenue. Heavy reliance on a single
              category exposes the business to demand shocks in that segment.
            </li>
            <li>
              <strong>Lowest-performing month:</strong> {worstMonth?.month} saw only {formatCurrency(worstMonth?.revenue ?? 0)} in revenue,
              suggesting seasonal weakness or insufficient promotional activity during that period.
            </li>
            <li>
              <strong>Salesperson disparity:</strong> The gap between top performer ({formatCurrency(topSalesperson?.revenue ?? 0)})
              and bottom performer ({formatCurrency(bottomSalesperson?.revenue ?? 0)}) suggests uneven territory allocation
              or capability gaps in the sales team.
            </li>
          </ul>
        </InsightCard>
      </div>

      {/* Recommendations */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="mb-4 flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-teal-500">
            <Lightbulb className="h-5 w-5 text-white" />
          </div>
          <h3 className="text-sm font-bold text-slate-700">Data-Driven Recommendations</h3>
        </div>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <div className="flex gap-3 rounded-lg border border-slate-100 bg-slate-50 p-3">
            <Target className="mt-0.5 h-5 w-5 shrink-0 text-teal-600" />
            <div>
              <p className="text-sm font-semibold text-slate-700">Reduce cancellation and return rates</p>
              <p className="text-xs text-slate-500">
                Investigate root causes for the {formatPercent(cancellationRate + returnRate)} non-completion rate.
                Implement pre-shipment quality checks, clearer product descriptions, and a return-reduction
                incentive program for salespeople. Target reducing combined cancellations and returns below 15%.
              </p>
            </div>
          </div>
          <div className="flex gap-3 rounded-lg border border-slate-100 bg-slate-50 p-3">
            <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-indigo-600" />
            <div>
              <p className="text-sm font-semibold text-slate-700">Expand underperforming regions</p>
              <p className="text-xs text-slate-500">
                {regions[regions.length - 1]?.region} is significantly underperforming. Deploy targeted marketing
                campaigns, add local sales representatives, and pilot a regional promotion to close the gap with
                top-performing {bestRegion?.region}.
              </p>
            </div>
          </div>
          <div className="flex gap-3 rounded-lg border border-slate-100 bg-slate-50 p-3">
            <Package className="mt-0.5 h-5 w-5 shrink-0 text-amber-600" />
            <div>
              <p className="text-sm font-semibold text-slate-700">Diversify category mix</p>
              <p className="text-xs text-slate-500">
                Reduce over-reliance on {bestCategory?.category} by cross-promoting lower-grossing categories like{' '}
                {categories[categories.length - 1]?.category}. Bundle complementary products and run cross-category
                discounts to balance revenue distribution.
              </p>
            </div>
          </div>
          <div className="flex gap-3 rounded-lg border border-slate-100 bg-slate-50 p-3">
            <TrendingUp className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" />
            <div>
              <p className="text-sm font-semibold text-slate-700">Optimize seasonal strategy</p>
              <p className="text-xs text-slate-500">
                {worstMonth?.month} underperformance suggests a seasonal trough. Schedule promotional events,
                flash sales, or new product launches during weak months. Study what drove the {bestMonth?.month} peak
                and replicate those conditions.
              </p>
            </div>
          </div>
          <div className="flex gap-3 rounded-lg border border-slate-100 bg-slate-50 p-3">
            <BarChart3 className="mt-0.5 h-5 w-5 shrink-0 text-blue-600" />
            <div>
              <p className="text-sm font-semibold text-slate-700">Invest in salesperson enablement</p>
              <p className="text-xs text-slate-500">
                The revenue gap between top and bottom salespeople is substantial. Implement a peer mentoring
                program where {topSalesperson?.salesperson} and other top performers share best practices.
                Rebalance territories to give underperformers higher-potential accounts.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Methodology */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="mb-3 flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-700">
            <BookOpen className="h-5 w-5 text-white" />
          </div>
          <h3 className="text-sm font-bold text-slate-700">Methodology</h3>
        </div>
        <div className="space-y-2 text-sm leading-relaxed text-slate-600">
          <p>
            <strong>Data source:</strong> A synthetic sales dataset of 500 transaction records for a mid-sized
            Indian retail/e-commerce company, covering January 2026 through August 2026. The dataset includes 17
            fields per order: order ID, date, region, state, city, salesperson, product, category, units sold, unit
            price, revenue, cost, profit, customer type, sales channel, payment method, and order status.
          </p>
          <p>
            <strong>Integrity constraints:</strong> Revenue is defined as Units Sold × Unit Price and Profit as
            Revenue − Cost. All 500 rows were programmatically validated against these constraints with zero
            discrepancies before analysis.
          </p>
          <p>
            <strong>Geographic scope:</strong> Orders span four regions (North, South, East, West) across 19 Indian
            states and 40+ cities. Salespeople are fictional identifiers — no real personal data is used.
          </p>
          <p>
            <strong>Product scope:</strong> 12 products across 5 categories — Electronics, Apparel, Home & Kitchen,
            Beauty & Personal Care, and Books & Stationery. Cost ratios vary by category (Electronics ~63–73%,
            Apparel ~43–53%, Home & Kitchen ~53–63%, Beauty ~35–45%, Books ~50–60%) to reflect realistic margin
            structures.
          </p>
          <p>
            <strong>Analytical approach:</strong> KPIs (Total Revenue, Total Profit, Total Orders, Units Sold,
            Average Order Value, Profit Margin) are computed by aggregating the filtered dataset. Trends are
            derived by grouping records by month. Regional, categorical, product, and salesperson breakdowns are
            computed via sum aggregation. Distributions (customer type, channel, order status) use count
            aggregation. All calculations are performed client-side in TypeScript from the raw CSV — no data is
            fabricated, altered, or pre-summarized.
          </p>
          <p>
            <strong>Filtering:</strong> All filters (date range, region, state, category, product, salesperson,
            customer type, sales channel, order status) are applied dynamically across the Dashboard, Data, and
            Insights views. KPIs and charts recalculate in real time as filters change.
          </p>
          <p>
            <strong>Tools:</strong> Built with React, TypeScript, Tailwind CSS, and Recharts. The dashboard is
            fully responsive and renders entirely in the browser.
          </p>
        </div>
      </div>
    </div>
  );
}
