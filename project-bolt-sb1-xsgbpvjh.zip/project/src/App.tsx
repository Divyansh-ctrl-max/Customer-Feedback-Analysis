import { useState } from 'react';
import { LayoutDashboard, Table2, Lightbulb, Store } from 'lucide-react';
import type { Filters, ViewType } from '@/types';
import { allRecords } from '@/data/parseData';
import DashboardView from '@/views/DashboardView';
import DataView from '@/views/DataView';
import InsightsView from '@/views/InsightsView';

const emptyFilters: Filters = {
  dateFrom: '', dateTo: '', region: '', state: '', category: '',
  product: '', salesperson: '', customerType: '', salesChannel: '', orderStatus: '',
};

const navItems: { id: ViewType; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'data', label: 'Data', icon: Table2 },
  { id: 'insights', label: 'Business Insights', icon: Lightbulb },
];

export default function App() {
  const [view, setView] = useState<ViewType>('dashboard');
  const [filters, setFilters] = useState<Filters>(emptyFilters);

  return (
    <div className="min-h-screen bg-slate-100">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 shadow-sm backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 shadow-md">
                <Store className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-base font-bold text-slate-800 sm:text-lg">Sales Analytics Dashboard</h1>
                <p className="hidden text-xs text-slate-400 sm:block">Indian Retail / E-Commerce | Jan – Aug 2026</p>
              </div>
            </div>
            <nav className="flex gap-1 rounded-lg bg-slate-100 p-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = view === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setView(item.id)}
                    className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition sm:px-4 ${
                      active
                        ? 'bg-white text-teal-700 shadow-sm'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span className="hidden sm:inline">{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        {view === 'dashboard' && (
          <DashboardView allRecords={allRecords} filters={filters} setFilters={setFilters} />
        )}
        {view === 'data' && (
          <DataView allRecords={allRecords} filters={filters} setFilters={setFilters} />
        )}
        {view === 'insights' && (
          <InsightsView allRecords={allRecords} filters={filters} setFilters={setFilters} />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-4">
        <div className="mx-auto max-w-7xl px-4 text-center text-xs text-slate-400 sm:px-6 lg:px-8">
          Sales Analytics Dashboard | Synthetic dataset of 500 orders | Built with React, TypeScript & Recharts
        </div>
      </footer>
    </div>
  );
}
