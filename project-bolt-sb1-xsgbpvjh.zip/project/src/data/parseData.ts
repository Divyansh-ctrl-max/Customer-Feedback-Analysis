import type { SalesRecord, Filters } from '@/types';
import salesCsv from './sales_data.csv?raw';

function parseCSV(csv: string): SalesRecord[] {
  const lines = csv.trim().split('\n');
  const headers = lines[0].split(',');
  const records: SalesRecord[] = [];
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',');
    const obj: Record<string, string> = {};
    headers.forEach((h, idx) => { obj[h.trim()] = values[idx]?.trim() ?? ''; });
    records.push({
      Order_ID: obj.Order_ID,
      Order_Date: obj.Order_Date,
      Region: obj.Region,
      State: obj.State,
      City: obj.City,
      Salesperson: obj.Salesperson,
      Product: obj.Product,
      Category: obj.Category,
      Units_Sold: parseInt(obj.Units_Sold, 10),
      Unit_Price: parseFloat(obj.Unit_Price),
      Revenue: parseFloat(obj.Revenue),
      Cost: parseFloat(obj.Cost),
      Profit: parseFloat(obj.Profit),
      Customer_Type: obj.Customer_Type,
      Sales_Channel: obj.Sales_Channel,
      Payment_Method: obj.Payment_Method,
      Order_Status: obj.Order_Status,
    });
  }
  return records;
}

export const allRecords: SalesRecord[] = parseCSV(salesCsv);

export function applyFilters(records: SalesRecord[], filters: Filters): SalesRecord[] {
  return records.filter((r) => {
    if (filters.dateFrom && r.Order_Date < filters.dateFrom) return false;
    if (filters.dateTo && r.Order_Date > filters.dateTo) return false;
    if (filters.region && r.Region !== filters.region) return false;
    if (filters.state && r.State !== filters.state) return false;
    if (filters.category && r.Category !== filters.category) return false;
    if (filters.product && r.Product !== filters.product) return false;
    if (filters.salesperson && r.Salesperson !== filters.salesperson) return false;
    if (filters.customerType && r.Customer_Type !== filters.customerType) return false;
    if (filters.salesChannel && r.Sales_Channel !== filters.salesChannel) return false;
    if (filters.orderStatus && r.Order_Status !== filters.orderStatus) return false;
    return true;
  });
}

export function getUniqueValues(records: SalesRecord[], field: keyof SalesRecord): string[] {
  return [...new Set(records.map((r) => r[field]))].sort();
}

export function getDateRange(records: SalesRecord[]): { min: string; max: string } {
  const dates = records.map((r) => r.Order_Date).sort();
  return { min: dates[0], max: dates[dates.length - 1] };
}
